#include <iostream>
#include "Account.h"
using namespace std;

Account::Account()
{
    count = 0;
}

void Account::addRecord()
{
    int choice;

    cout << "1.���J 2.��X: ";
    cin >> choice;

    if (choice == 1)
        type[count] = "���J";
    else
        type[count] = "��X";

    cout << "����: ";
    cin >> category[count];

    cout << "���B: ";
    cin >> amount[count];

    count++;

    cout << "�s�W���\�I" << endl;
}

void Account::showRecords()
{
    for (int i = 0;i < count;i++)
    {
        cout << i + 1 << ". "
            << type[i] << " / "
            << category[i] << " / "
            << amount[i] << endl;
    }
}

void Account::deleteRecord()
{
    int num;
    showRecords();

    cout << "�R���s��: ";
    cin >> num;

    for (int i = num - 1;i < count - 1;i++)
    {
        type[i] = type[i + 1];
        category[i] = category[i + 1];
        amount[i] = amount[i + 1];
    }

    count--;
}

int Account::getCount()
{
    return count;
}

string Account::getType(int i)
{
    return type[i];
}

double Account::getAmount(int i)
{
    return amount[i];
}