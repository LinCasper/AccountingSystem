#include <iostream>
#include "Account.h"
#include "Report.h"
using namespace std;

int main()
{
    Account acc;
    Report rep;

    int choice;

    do
    {
        cout << endl;
        cout << "1.�s�W�O�b" << endl;
        cout << "2.��ܬ���" << endl;
        cout << "3.�R������" << endl;
        cout << "4.�έp����" << endl;
        cout << "0.���}" << endl;
        cin >> choice;

        switch (choice)
        {
        case 1: acc.addRecord(); break;
        case 2: acc.showRecords(); break;
        case 3: acc.deleteRecord(); break;
        case 4: rep.showSummary(acc); break;
        }

    } while (choice != 0);

    return 0;
}