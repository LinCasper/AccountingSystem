#include <iostream>
#include "Report.h"
using namespace std;

void Report::showSummary(Account& acc)
{
    double income = 0;
    double expense = 0;

    for (int i = 0;i < acc.getCount();i++)
    {
        if (acc.getType(i) == "���J")
            income += acc.getAmount(i);
        else
            expense += acc.getAmount(i);
    }

    cout << "�`���J: " << income << endl;
    cout << "�`��X: " << expense << endl;
    cout << "���l: " << income - expense << endl;
}